package jadx.api.data.annotations;

public interface ICodeRawOffset {
	int getOffset();
}
