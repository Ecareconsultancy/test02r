package jadx.core.dex.instructions.args;

public interface Named {

	String getName();

	void setName(String name);
}
