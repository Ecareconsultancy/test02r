package jadx.core.dex.nodes;

public interface IDexNode {

	String typeName();

	RootNode root();

	String getInputFileName();
}
